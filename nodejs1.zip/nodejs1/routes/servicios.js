const express = require("express");

const axios = require("axios");

const router = express.Router();

const fs = require("fs"); //file system

const pokeApiUrl = "https://pokeapi.co/api/v2/pokemon/"; 

//http codes
//100 - informacion
//200 - exitoso
//300 - redireccion
//400 - error de cliente
//500 - error de servidor



//RUTAAAAAAAAAAAS
/*GET: SOLICITAR INFO AL SERVIDOR 

        ENVIA DATOS AL SERVIDOR A TRAVES DE URL (OBSERVABLE)
*/

/*POST: ENVIAE DATOS A SERVIDOR 

        ENVIA DATOS A TRAVES DE OBJETO BODY
        req.body asi se accede al cuerpo de la petición
        DEBERIAMOS USAR POST SÓLO PARA CREAR COSAS
        EJEM. GUARDAR ALGO EN UNA BASE DE DATOS
*/

/*PUT: ENVIA DATOS AL SERVIDOR

        ENVIA DATOS A TRAVES DE OBJETO BODY
        PERO ESTE SIRVE PARA EDITAR
*/
/*DELETE: ENVIA DATOS A ¿L SERVIDOR

        A TRAVES DE OBJETO BODY
        Y ELIMINA CONTENIDO
*/

router.get("/obtenerUsuario", (req, res) => {
    let usuario = {
        name: "Pauffy",
        email: "pauffy707@gmail.com",
        active: true

    }

    res.json({usuario});
});

 router.post("/login", (req, res) =>{
    let usuarioBD = {
        correo: "pauffy777@alumnos.udg",
        key: "nombre de mi mascota"
    }
    console.log(req.body);
    let usuarioLogin = req.body;
    let mensaje = "";

    if(usuarioLogin.correo == usuarioBD.correo && usuarioLogin.key == usuarioBD.key){
        mensaje = "OK";

    }else{
        mensaje = "ERROR!";
    }

    res.json({mensaje});

 });

 router.get("/obtenerPokemons", (req,res) =>{

    axios.get(pokeApiUrl)
    .then( (response) =>{
        //console.log(response);
        res.status(200).json(response.data);
        
    })
 });

 router.get("/obtenerPorID/:id", (req,res) =>{
   let id = req.params.id;//params es basicamente el url
   axios.get(pokeApiUrl + id)
   .then((response) =>{

    let data = response.data;
    res.json({data});
   }).catch(  (err) =>{
    res.status(500).send(err);
   })


 });

 router.get("/guardarArchivoPokemon/:id", (req,res) =>{
    let id = req.params.id;
    console.log(id);
    axios.get(pokeApiUrl + id)
    .then( async(response) => {
        let data = {
            name: response.data.name,
            id: response.data.id,
            height: response.data.height,
            weight: response.data.weight,
            types: response.data.types

        };
        try{
            await fs.promises.writeFile("pokemonID.txt", JSON.stringify(data));

        }catch(error){
            console.log(error);
        }
        res.json(data);

    }).catch(  (err) =>{
    res.status(500).send(err);
   })


 });

module.exports = router;