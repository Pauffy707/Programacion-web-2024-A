const express = require("express");
const router = express.Router();
const Note = require("../models/note");

//REGRESAR TODAS LAS NOTAS DE LA BD
router.get("/", async (req,res) =>{
    let notes = await Note.find();
    res.json(notes);
});

//Crear nueva nota!
router.post("/crear", async (req, res) =>{
    //console.log(req.body);
    const newNote = new Note(req.body);
    const notaGuardada = await newNote.save();
    res.json({message: "Nota guardada", newNote:notaGuardada});

});

router.put("/:id", async(req, res) =>{
    try{
        const {  title, content } = req.body;
        const noteId = req.params.id;

        const notaActualizada = await Note.findByIdAndUpdate(noteId, {
            title: title,
            content:content
        });

        //revisar que nota actualizada contenga datos
        if(!notaActualizada){
            return res.status(400).json({mensaje: "No se encontro la nota"});
        }

        res.json(notaActualizada);



    }catch(error){
        res.status(500).json({mensaje:"Error al editar"}, error)
    }

});

module.exports = router;