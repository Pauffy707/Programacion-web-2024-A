const mongoose = require("mongoose");

//DEFINIR ESQUEMA DE MODELO (SIMILAR A UNA CLASE)

const noteSchema = new mongoose.Schema({
    title: String,
    content: String,
});

const  Note = mongoose.model("Note" , noteSchema);

module.exports = Note;

//MISMA ESTRUCTURA PARA TODOS LOS ESQUEMA, SE PUEDE HASTA COPIAR Y PEGAR.