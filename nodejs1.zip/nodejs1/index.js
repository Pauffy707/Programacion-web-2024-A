const express = require("express");
const mongoose = require("mongoose");

const app = express(); //construir servidor inicial

app.set("port", 3000);
//req = request (lo que recibimos desde el navagadoe/servidor)
//res = response
mongoose.connect("mongodb+srv://prograweb:prograweb1324@directorio.5pb0e.mongodb.net/ClaseWeb?retryWrites=true&w=majority&appName=Directorio").then( () => {
    console.log("Conexion exitosa a la BD");

}).catch( (err) => {
    console.log("Error a conectarse a la BD", err.message);
})

app.get("/", (req,res) =>{
    res.send("Hola mundo en Express/Node");

});

app.use(
    express.json()
)
//SERVICIOS APPI

app.use("/api/servicios", require("./routes/servicios"));

app.use("/api/proyecto", require("./routes/proyecto"));

//vamos a levantar el servidor
app.listen(app.get("port"), function(){ 
    console.log("Servidor escuchando y ejecutando "+app.get("port"))
 });